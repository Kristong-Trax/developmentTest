SET FOREIGN_KEY_CHECKS=0;
-- added by prasanna
ALTER TABLE probedata.match_product_in_scene_recognition ADD COLUMN is_overlap varchar(2) DEFAULT NULL;
-- to fix is_overlap column not found issue, during seed creation